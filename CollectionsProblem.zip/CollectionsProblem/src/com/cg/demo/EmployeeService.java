package com.cg.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmployeeService {

	List<Employee> list = EmployeeRepository.getEmployees();

	public Employee getEmployee(int id, String name) {// 111 sandeep
		// display the Employee details based on id or name iterate the list check id
		// and name when matching return obj
		Employee matchingEmp = null;
		for (Employee emp : list)
			if (emp.getId() == id && emp.getName().equals(name))
				matchingEmp = emp;
		return matchingEmp;
	}

	public List<Employee> getEmployees(Double salary) {
		// display the names of employees who are getting the salary greater than the
		// 60000
		// salary given
		List<Employee> matchingEmp = new ArrayList<Employee>();
		for (Employee emp : list)
			if (emp.getSalary() > 60000)
				matchingEmp.add(emp);
		return matchingEmp;
	}

	public Double getMaxSalary() {
		// display the max salary
		double maxSalary = 0;
		double salary = 0;
		for (Employee employee : list) {
			salary = employee.getSalary();// 1000,800,1100
			if (maxSalary < salary)
				maxSalary = salary;
		}
		return maxSalary;
	}

	public Double getSumOfSalary() {
		// display the sum of salaries of all the employees
		double sumOfSalary = 0;
		double salary = 0;
		for (Employee employee : list) {
			salary = employee.getSalary();// 1000,800,1100
			sumOfSalary += salary;
		}
		return sumOfSalary;

	}

	public List<String> getNames(String city) {
		// display the names of all employees who are working in 'Pune'
		List<String> names = new ArrayList<String>();
		for (Employee employee : list) {
			String location = employee.getLocation();// 1000,800,1100
			if (location.equalsIgnoreCase(city)) {
				names.add(employee.getName());
			}
		}
		return names;
	}

	public List<Employee> getDetails() {
		// display all employees based on salary ascending
		Collections.sort(list);
		return list;
	}

	public List<Employee> getManagers() {
		// display all employees who are working as managers
		List<Employee> managers = new ArrayList<Employee>();
		for (Employee employee : list) {
			if (employee.getDesignation().equalsIgnoreCase("manager")) {
				managers.add(employee);
			}
		}
		return managers;
	}

	public Double getSumOfManagerSalaries() {
		// display the sum of salaries of employees who are working as managers
		double sumOfSalary = 0;
		double salary = 0;
		for (Employee employee : list) {
			if (employee.getDesignation().equalsIgnoreCase("manager")) {
				salary = employee.getSalary();
				sumOfSalary += salary;
			}
		}
		return sumOfSalary;
	}

	public List<Integer> getIds() {
		// display the ids of all employees
		List<Integer> ids=new ArrayList<Integer>();
		for (Employee employee : list) {
				ids.add(employee.getId());
		}
		return ids;
	}
}
