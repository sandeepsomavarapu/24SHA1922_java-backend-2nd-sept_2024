package com.cg.demo;

import java.util.Iterator;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		EmployeeService service = new EmployeeService();
		System.out.println("*****Employee info for given id and name*****");
		System.out.println(service.getEmployee(156507, "pavan kumar"));
		System.out.println("*****List of Employees whose getting above given salary***");
		List<Employee> empsAboveSalary = service.getEmployees(60000.0);
		for (Employee emp : empsAboveSalary) {
			System.out.println(emp);
		}
		System.out.println("*****Display Maximum Salary*****");
		System.out.println(service.getMaxSalary());
		System.out.println("*****Display Sum Of Salaries*****");
		System.out.println(service.getSumOfSalary());
		System.out.println("***Displaying Employee Names who are from given city ***");
		List<String> names = service.getNames("pune");
		for (String name : names) {
			System.out.println(name);
		}
		System.out.println("Diplaying only managers :");
		List<Employee> managers = service.getManagers();
		for (Employee emp : managers) {
			System.out.println(emp);
		}
		System.out.println("Sum of the salaries of managers ");
		System.out.println(service.getSumOfManagerSalaries());
		System.out.println("Ascending order based on salaries");
		List<Employee> empsInAscending=service.getDetails();
		for(Employee emp:empsInAscending)
		{
			System.out.println(emp);
		}
		System.out.println("Dsiplaying All the employee ids");
		System.out.println(service.getIds());
		
		
	}

}
