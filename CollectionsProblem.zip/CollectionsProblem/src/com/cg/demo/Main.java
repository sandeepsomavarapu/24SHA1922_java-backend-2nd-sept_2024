package com.cg.demo;

import java.util.Iterator;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		EmployeeService service = new EmployeeService();
		System.out.println("*****Employee info for given id and name*****");
		System.out.println(service.getEmployee(156507, "pavan kumar"));
		System.out.println("*****List of Employees whose getting above given salary***");
		List<Employee> empsAboveSalary = service.getEmployees(60000.0);
		for (Employee emp : empsAboveSalary) {
			System.out.println(emp);
		}

	}

}
