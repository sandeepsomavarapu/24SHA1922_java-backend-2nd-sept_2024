import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import net.sf.cglib.core.GeneratorStrategy;

@Entity
@Table(name = "india_emps")
//@NamedQueries({		
//
//	@NamedQuery(name="Employee.getMaxSal",query="select max(emp.esal) FROM Employee emp")
//})

//@NamedNativeQueries({
//	@NamedNativeQuery(name="fetchAll",query="select * from sleepingemps")
//})				      select empid from india_emps; mysql
public class Employee { //select e.eid from Employee e; jpql database independent query
	@Id
	@Column(name = "empid", length = 10)
	@GeneratedValue //unique sequential values-->1 ,+1
	private int eid;
	@Column(name = "empname", length = 10)
	private String ename;
	@Column(name = "salary", length = 10)
	private int esal;

	public Employee() {
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getEsal() {
		return esal;
	}

	public void setEsal(int esal) {
		this.esal = esal;
	}

	public Employee(String ename, int esal) {
		super();

		this.ename = ename;
		this.esal = esal;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", esal=" + esal + "]";
	}

}
