import com.ericsson.corejava.*;

public class Welcome {
	public static void main(String args[]) throws CloneNotSupportedException {// main ctrl+Space
		Welcome wel=new Welcome();
		wel.m1();
	
	}

	public void m1() {
		System.out.println("m1 method");
	}
}
