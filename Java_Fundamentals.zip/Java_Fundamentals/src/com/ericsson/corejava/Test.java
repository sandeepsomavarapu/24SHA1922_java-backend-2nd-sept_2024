package com.ericsson.corejava;

public class Test {
public static void main(String[] args) {//"12",13
	//wrapper clsses 8 DT 
	
	int a=Integer.parseInt(args[0]);
	int b=Integer.parseInt(args[1]);

	int result=a+b;
	System.out.println("Add of two numbers :"+result);
}
}
