package com.ericsson.oops;

class Person {
	 int age = 89;

	public void printAge() {  //final
		++age;
		System.out.println("Age is :" + age);
	}

	public void info() {
		System.out.println("Person Name is 'suresh' and he's from 'india'");
	}
}

public class AgeCalculator extends Person {

	public static void main(String[] args) {
		AgeCalculator obj = new AgeCalculator();
		obj.printAge();
		obj.info();
		System.out.println(obj.age);
	}
	@Override
	public void printAge() {
		--age;
		System.out.println("Age is :" + age);
	}
}
