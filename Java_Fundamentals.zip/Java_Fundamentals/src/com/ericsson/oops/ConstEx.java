package com.ericsson.oops;

public class ConstEx {

	public ConstEx() {
		System.out.println("default constructor");
	}

	public ConstEx(String name) {
		System.out.println("param constructor :" + name);
	}

	public void sayHello() {
		System.out.println("Hello everyone!!!");
	}

	public static void main(String[] args) {

		ConstEx obj = new ConstEx("ericsson");
		obj.sayHello();

	}

}
