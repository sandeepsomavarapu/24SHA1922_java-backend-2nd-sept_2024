package com.ericsson.oops;

public class EmployeeClient {

	public static void main(String[] args) {
		Employee emp = new Employee();

		emp.setEmpId(123);
		emp.setEmpName("mahesh");
		emp.setEmpSalary(9000);
		emp.setEmpDesi("developer");

		System.out.println(emp.getEmpName());
	}

}
