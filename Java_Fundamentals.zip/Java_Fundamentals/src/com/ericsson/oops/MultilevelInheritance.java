package com.ericsson.oops;

public class MultilevelInheritance extends MobileCalCulator {
	public static void main(String[] args) {
		MultilevelInheritance obj = new MultilevelInheritance();
		obj.addition(12, 12);
		obj.sub(12, 9);
		obj.mul(12, 8);
	}

}
