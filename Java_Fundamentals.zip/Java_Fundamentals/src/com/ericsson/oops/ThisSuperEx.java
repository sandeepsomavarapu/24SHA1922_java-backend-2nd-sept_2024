package com.ericsson.oops;

class ParentEx {
	int marks = 222;

	public ParentEx() {
		this("suresh");
		System.out.println("ParentEx default constructor");
	}

	public ParentEx(String name) {
		System.out.println("ParentEx param constructor : " + name);
	}

	public void display() {
		System.out.println("am from parent display method");
	}
}

public class ThisSuperEx extends ParentEx {
	int marks = 900;

	public ThisSuperEx() {
		// super()
		this("mahesh");
		System.out.println("default constructor of current class");
		this.display();
		super.display();
	}

	public ThisSuperEx(String name) {
		System.out.println(this+" :inside constructor ");
		System.out.println("param constructor of current class :" + name);
	}

	public void printMarks(int marks) {
		System.out.println(this.marks + " " + marks + " " + super.marks);
	}

	@Override
	public void display() {
		System.out.println("am from child overridden display method");
	}
	@Override
	public String toString() {
		System.out.println(super.toString());
		return "sandeep";
	}
	public static void main(String[] args) {
		ThisSuperEx obj = new ThisSuperEx();//heap area,method area
		obj.printMarks(444);
		System.out.println(obj);
		System.out.println(obj.toString());// getClass().getName() + '@' + Integer.toHexString(hashCode())
		ThisSuperEx obj1=new ThisSuperEx();
				System.out.println(obj1);

	}
}
