package pack1;
import java.util.Date;
public class Parent {
	public  void myMethod() {
		System.out.println("Today's Date : " + new Date());
	}

	public static void main(String[] args) {
		Parent parent = new Parent();
		parent.myMethod();// Same Class
	}
}

class Test extends Parent {
	public void m1() {
		myMethod();// same package sub-class
	}
}

class Hello {
	public void m2() {
		Parent parent = new Parent();
		parent.myMethod();// same package non-subclass
	}
}
