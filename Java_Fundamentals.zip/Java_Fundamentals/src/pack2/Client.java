package pack2;

import pack1.Parent;

public class Client extends Parent {
	public static void main(String[] args) {
		Client client=new Client();
		client.myMethod();//different package sub-class
	}
}
class Myclass
{
	public void m3()
	{
		Client client=new Client();
		client.myMethod();//different package non-subclass
	}
}
