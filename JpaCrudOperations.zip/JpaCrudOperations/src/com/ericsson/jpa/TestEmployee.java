package com.ericsson.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestEmployee {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysql");
		EntityManager em = emf.createEntityManager();
		// insert-->persist(),update--->merge(),delete--->remove(),select-->find(),createQuery()
		//Employee emp = new Employee("sandeep", 65000, "developer");
		em.getTransaction().begin();
		//em.persist(emp);
		Employee employee=em.find(Employee.class, 5);
		System.out.println(employee.getEmpSal());
		System.out.println(employee.getEmpName());
		
//		employee.setEmpName("ericsson");
//		employee.setEmpSal(12345);
//		
//		em.merge(employee);//ORM
		em.remove(employee);
		

		em.getTransaction().commit();
	}

}
