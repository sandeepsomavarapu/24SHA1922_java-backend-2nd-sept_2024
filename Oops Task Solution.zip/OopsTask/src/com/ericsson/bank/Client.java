package com.ericsson.bank;

import com.ericsson.bank.model.CurrentAccount;
import com.ericsson.bank.model.Person;
import com.ericsson.bank.model.SavingsAccount;

public class Client {

	public static void main(String[] args) {
//		Person person = new Person();
//		person.setName("smith");
//		person.setAge(32);
//
//		Account acc1 = new Account();
//		acc1.setAccHolder(person);
//		acc1.setBalance(2000);
//
//		System.out.println(acc1);
//		acc1.deposit(2000);
//		
//		
//		System.out.println("After Deposit");
//		
//		System.out.println(acc1.getBalance());
//
//		Person person1 = new Person();
//		person1.setName("kathy");
//		person1.setAge(36);
//
//		Account acc2 = new Account();
//		acc2.setAccHolder(person1);
//		acc2.setBalance(3000);
//		System.out.println(acc2);
//		acc2.withdraw(20000);
//		System.out.println("After Withdraw");
//		System.out.println(acc2.getBalance());

		Person person2 = new Person();
		person2.setName("sandeep");
		person2.setAge(32);
		SavingsAccount savingsAcc = new SavingsAccount();
		savingsAcc.setAccHolder(person2);
		savingsAcc.setBalance(5000);

		System.out.println(savingsAcc);

		savingsAcc.withdraw(4001);

		System.out.println(savingsAcc);

		CurrentAccount currentAcc = new CurrentAccount();
		currentAcc.setAccHolder(person2);
		currentAcc.setBalance(5000);

		System.out.println(currentAcc);

		currentAcc.withdraw(4001);

		System.out.println(currentAcc);

	}

}
