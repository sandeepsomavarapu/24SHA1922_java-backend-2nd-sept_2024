package com.ericsson.bank.model;

import java.util.Random;

public class Account {// is-a , has-a
	private long accNum;
	private double balance;// -200
	private Person accHolder;// has-a

	public Account() {
		Random random = new Random();
		accNum = random.nextLong(2000);
	}

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public void setBalance(double balance) {
		if (balance >= 500)
			this.balance = balance;
		else
			System.out.println("Minimum Balance 500 Required");
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

	public void deposit(double amountToDepsoit) {
		this.balance = this.balance + amountToDepsoit;
	}

	public void withdraw(double amountToWithdraw) {
		this.balance = this.balance - amountToWithdraw;
	}

	public double getBalance() {
		return this.balance;
	}

	@Override
	public String toString() {
		return "Account Info: [accNum=" + accNum + ", balance=" + balance + ", accHolder=" + accHolder + "]";
	}

}
