package com.ericsson.bank.model;

public class CurrentAccount extends Account {
	double overDraftLimit = 2000;
	boolean result = false;

	@Override
	public void withdraw(double amountToWithdraw) {
		double availableBalance = getBalance();
		if (amountToWithdraw < availableBalance) {
			double updateBalance = availableBalance - amountToWithdraw;
			if (updateBalance > overDraftLimit)
				setBalance(updateBalance);
			else
				System.out.println("Overdraft Limit Reached : " + !result);
		} else {
			System.out.println("Insufficient Funds");
		}
	}

}
