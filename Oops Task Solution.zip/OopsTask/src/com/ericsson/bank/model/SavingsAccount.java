package com.ericsson.bank.model;

public class SavingsAccount extends Account {
	final double minimumBalance = 1000;

	@Override
	public void withdraw(double amountToWithdraw) {
		double availableBalance = getBalance();
		if (amountToWithdraw < availableBalance) {
			double updateBalance = availableBalance - amountToWithdraw;
			if (updateBalance > minimumBalance)
				setBalance(updateBalance);
			else
				System.out.println("Not Meeting Minimum Balance");
		} else {
			System.out.println("Insufficient Funds");
		}
	}

}
