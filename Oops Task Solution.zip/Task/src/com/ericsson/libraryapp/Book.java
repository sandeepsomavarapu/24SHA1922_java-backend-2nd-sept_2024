package com.ericsson.libraryapp;

public class Book extends WrittenItem {
	private String author;

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public String checkIn() {

		return super.checkIn() + "By Author" + author;
	}

	@Override
	public String checkOut() {

		return super.checkOut() + "By author " + author;
	}
}
