package com.ericsson.libraryapp;

public class CD extends MediaItem {
	private String artist;
	private String musicalGenre;

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getMusicalGenre() {
		return musicalGenre;
	}

	public void setMusicalGenre(String musicalGenre) {
		this.musicalGenre = musicalGenre;
	}

	@Override
	public void print() {
		super.print();
		System.out.println(artist+" "+musicalGenre);
	}

}
