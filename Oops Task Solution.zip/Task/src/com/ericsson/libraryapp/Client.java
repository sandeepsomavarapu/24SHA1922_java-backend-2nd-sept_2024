package com.ericsson.libraryapp;

public class Client {

	public static void main(String[] args) {
		Book book = new Book();
		book.setItemId(123);
		book.setTitle("Core Java");
		book.setNumberOfCopies(35);
		book.setAuthor(" James Gosling");
		System.out.println(book.checkIn());

	}

}
