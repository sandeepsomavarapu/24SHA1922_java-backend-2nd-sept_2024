package com.ericsson.libraryapp;

public abstract class Item {
	private int itemId;
	private String title;
	private int numberOfCopies;

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getNumberOfCopies() {
		return numberOfCopies;
	}

	public void setNumberOfCopies(int numberOfCopies) {
		this.numberOfCopies = numberOfCopies;
	}

	public Item() {
		System.out.println("default constructor");
	}

	public Item(int itemId, String title, int numberOfCopies) {
		super();
		this.itemId = itemId;
		this.title = title;
		this.numberOfCopies = numberOfCopies;
	}

	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", title=" + title + ", numberOfCopies=" + numberOfCopies + "]";
	}

	public String addItem() {
		return "Item Added";
	}

	public String checkIn() {
		return "Item checked IN";
	}

	public String checkOut() {
		return "Item checked Out";
	}

	public void print() {
		System.out.println("Item [itemId=" + itemId + ", title=" + title + ", numberOfCopies=" + numberOfCopies + "]");
	}

}
