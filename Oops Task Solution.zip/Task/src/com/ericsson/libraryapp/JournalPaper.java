package com.ericsson.libraryapp;

public class JournalPaper extends WrittenItem {
	private String yearOfPublish;

	public String getYearOfPublish() {
		return yearOfPublish;
	}

	public void setYearOfPublish(String yearOfPublish) {
		this.yearOfPublish = yearOfPublish;
	}

	@Override
	public String addItem() {
		return super.addItem() + " with Year of Publish" + yearOfPublish;
	}
}
