package com.ericsson.libraryapp;

public class MediaItem extends Item {

	@Override
	public String toString() {
		return super.toString();
	}

}
