package com.ericsson.libraryapp;

public class Video extends MediaItem {
	private String yearOfRealse;
	private String director;
	private String genre;

	public String getYearOfRealse() {
		return yearOfRealse;
	}

	public void setYearOfRealse(String yearOfRealse) {
		this.yearOfRealse = yearOfRealse;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	@Override
	public void print() {

		super.print();
		System.out.println(yearOfRealse + " " + director + " " + genre);
	}
}
