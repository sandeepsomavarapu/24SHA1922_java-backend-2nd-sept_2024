package com.ericsson.libraryapp;

public class WrittenItem extends Item {

	@Override
	public String checkIn() {
		return "Written Item Checkd In";
	}
}
