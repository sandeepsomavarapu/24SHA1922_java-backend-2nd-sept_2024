package com.ericsson.productapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ericsson.productapp.entity.Product;
import com.ericsson.productapp.service.ProductService;

@RestController
//@Controller+@ResponseBody-->RestController
@RequestMapping("/products") // http://localhost:8080/products
public class ProductController {

	@Autowired
	ProductService service;

	@PostMapping("/saveproduct") // http://localhost:8080/products/saveproduct
	public String addProduct(@RequestBody Product product) {
		return service.addProduct(product);
	}

	@PutMapping("/mergeproduct") // http://localhost:8080/products/mergeproduct
	public Product updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/removeproduct/{pid}") // http://localhost:8080/products/removeproduct/123
	public String deleteProduct(@PathVariable("pid") int productId) {
		return service.deleteProduct(productId);
	}

	@GetMapping("/getproduct/{pid}") // http://localhost:8080/products/getproduct/123
	public Product getProduct(@PathVariable("pid") int productId) {
		return service.getProduct(productId);
	}

	@GetMapping("/getproducts") // http://localhost:8080/products/getproducts
	public List<Product> getAllProducts() {
		return service.getAllProducts();
	}

	@GetMapping("/getproductsbetween/{price1}/{price2}") // http://localhost:8080/products/getproductsbetween/1000/2000
	public List<Product> getProductsBetween(@PathVariable("price1") int intialPrice,
			@PathVariable("price2") int finalPrice) {
		return service.getProductsBetween(intialPrice, finalPrice);
	}

	@GetMapping("/getproductsbycategory/{category}") // http://localhost:8080/products/getproductsbycategory/toys
	public List<Product> getProductsByCategory(@PathVariable("category") String productCategory) {

		return service.getProductsByCategory(productCategory);
	}

}
