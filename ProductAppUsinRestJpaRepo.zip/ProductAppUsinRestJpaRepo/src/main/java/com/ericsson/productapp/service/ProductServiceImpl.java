package com.ericsson.productapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ericsson.productapp.entity.Product;
import com.ericsson.productapp.repository.ProductRepo;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepo repo;

	@Override
	public String addProduct(Product product) {
		repo.save(product);
		return "Product saved !!!";
	}

	@Override
	public Product updateProduct(Product product) {

		return repo.save(product);
	}

	@Override
	public String deleteProduct(int productId) {
		repo.deleteById(productId);
		return "product deleted !!";
	}

	@Override
	public Product getProduct(int productId) {
		Optional<Product> optional = repo.findById(productId);
		return optional.get();
	}

	@Override
	public List<Product> getAllProducts() {

		return repo.findAll();// select p from Product p;
	}

	@Override
	public List<Product> getProductsBetween(int intialPrice, int finalPrice) {

		return repo.findByProductPriceBetween(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getProductsByCategory(String productCategory) {

		return repo.findByProductCategory(productCategory);
	}

}
