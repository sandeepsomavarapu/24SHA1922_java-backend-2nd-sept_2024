package com.ericsson.productapp.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ericsson.productapp.entity.Product;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Repository
public class ProductRepoImpl implements ProductRepo {

	// entitymanager--persist,merge,remove,find,createQuery
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addProduct(Product product) {
		entityManager.persist(product);
		return "Product Persisted Successfully";
	}

	@Override
	public Product updateProduct(Product product) {

		return entityManager.merge(product);
	}

	@Override
	public String deleteProduct(int productId) {
		entityManager.remove(getProduct(productId));
		return "Product Deleted ....";
	}

	@Override
	public Product getProduct(int productId) {

		return entityManager.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProducts() {
		TypedQuery<Product> products = entityManager.createQuery("select p from Product p", Product.class);
		List<Product> prods = products.getResultList();
		return prods;
	}

	@Override
	public List<Product> getProductsBetween(int intialPrice, int finalPrice) {
		TypedQuery<Product> products = entityManager
				.createQuery("select p from Product p where p.productPrice between ?1 and ?2", Product.class);
		products.setParameter(1, intialPrice);
		products.setParameter(2, finalPrice);
		List<Product> prods = products.getResultList();
		return prods;
	}

	@Override
	public List<Product> getProductsByCategory(String productCategory) {
		TypedQuery<Product> products = entityManager.createQuery("select p from Product p where p.productCategory=?1",
				Product.class);
		products.setParameter(1, productCategory);
		List<Product> prods = products.getResultList();
		return prods;
	}

}
