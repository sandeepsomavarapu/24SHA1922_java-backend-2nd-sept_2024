package com.ericsson.productapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductAppUsingJpaHIbernateRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
