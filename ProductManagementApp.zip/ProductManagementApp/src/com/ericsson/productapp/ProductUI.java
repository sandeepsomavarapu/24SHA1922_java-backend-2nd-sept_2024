package com.ericsson.productapp;

import java.util.Scanner;

import com.ericsson.productapp.exceptions.ProductNotFound;
import com.ericsson.productapp.models.Product;
import com.ericsson.productapp.service.ProductService;
import com.ericsson.productapp.service.ProductServiceImpl;

public class ProductUI {

	public static void main(String[] args) {
		int productId;
		String productName;
		float productPrice;
		String productCategory;
		int productQuantity;
		ProductService service = new ProductServiceImpl();
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("************Product Management App*************");
			System.out.println("	Product	Management App			\r\n" + "	1.ADD Product\r\n"
					+ "	2.Update product\r\n" + "	3.Delete product\r\n" + "	4.Get Product			\r\n"
					+ "	5.Get All Products\r\n" + "	6.Get Products between the prices\r\n"
					+ "	7.Get products by category\r\n" + "	8.Exit	");
			int option = scan.nextInt();

			switch (option) {
			case 1:
				System.out.println("Enter Details Add Product");
				System.out.println("Enter the product id ");
				productId = scan.nextInt();
				System.out.println("Enter the product name ");
				productName = scan.next();
				System.out.println("Enter the product price ");
				productPrice = scan.nextFloat();
				System.out.println("Enter the product category ");
				productCategory = scan.next();
				System.out.println("Enter the quantity");
				productQuantity = scan.nextInt();
				Product product = new Product(productId, productName, productPrice, productCategory, productQuantity);
				System.out.println(service.addProduct(product));
				break;
			case 2:
				System.out.println("Enter Details Update Product");
				System.out.println("Enter the existing product id ");
				productId = scan.nextInt();
				System.out.println("Enter the product name ");
				productName = scan.next();
				System.out.println("Enter the product price ");
				productPrice = scan.nextFloat();
				System.out.println("Enter the product category ");
				productCategory = scan.next();
				System.out.println("Enter the quantity");
				productQuantity = scan.nextInt();
				product = new Product(productId, productName, productPrice, productCategory, productQuantity);
				try {
					System.out.println(service.updateProduct(product));
				} catch (ProductNotFound exception) {
					System.out.println("Invalid Product Id: ");
				}
				break;
			case 3:
				System.out.println("Enter the existing product id to delete ");
				productId = scan.nextInt();
				try {
					System.out.println(service.deleteProduct(productId));
				} catch (ProductNotFound e) {
					System.out.println("Invalid Product Id");
				}
				break;
			case 4:
				System.out.println("Enter the existing product id to get ");
				productId = scan.nextInt();
				try {
					System.out.println(service.getProduct(productId));
				} catch (ProductNotFound e) {
					System.out.println("Product Id is Invalid ");
				}
				break;
			case 5:
				service.getAllProducts().forEach(System.out::println);
				break;
			case 6:
				System.out.println("Enter the product intial price ");
				float intialPrice = scan.nextFloat();
				System.out.println("Enter the product final price ");
				float finalPrice = scan.nextFloat();
				service.getProductsBetween(intialPrice, finalPrice).forEach(System.out::println);
				break;
			case 7:
				System.out.println("Enter the product category ");
				productCategory = scan.next();
				service.getProductsByCategory(productCategory).forEach(System.out::println);
				break;
			default:
				scan.close();
				System.out.println("Thank You !!!");
				System.exit(0);
				break;
			}

		}
	}
}
