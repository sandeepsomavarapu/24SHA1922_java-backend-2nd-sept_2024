package com.ericsson.productapp.dao;

import java.util.List;

import com.ericsson.productapp.exceptions.ProductNotFound;
import com.ericsson.productapp.models.Product;

public interface ProductDAO {

	public abstract String addProduct(Product product);

	public abstract Product updateProduct(Product product) throws ProductNotFound;

	public abstract String deleteProduct(int productId) throws ProductNotFound;

	public abstract Product getProduct(int productId) throws ProductNotFound;

	public abstract List<Product> getAllProducts();

	public abstract List<Product> getProductsBetween(float intialPrice, float finalPrice);

	public abstract List<Product> getProductsByCategory(String productCategory);

}
