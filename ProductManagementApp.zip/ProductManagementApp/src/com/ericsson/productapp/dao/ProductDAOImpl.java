package com.ericsson.productapp.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.ericsson.productapp.exceptions.ProductNotFound;
import com.ericsson.productapp.models.Product;

public class ProductDAOImpl implements ProductDAO {

	HashMap<Integer, Product> products = new HashMap<Integer, Product>();

	@Override
	public String addProduct(Product product) {
		products.put(product.getProductId(), product);// put--insert when new id passed /update when existing id passed
		return "Product Saved Successfully";
	}

	@Override
	public Product updateProduct(Product product) throws ProductNotFound {
		Product matchProduct = getProduct(product.getProductId());
		if (matchProduct != null)
			products.put(product.getProductId(), product);
		return getProduct(product.getProductId());

	}

	@Override
	public String deleteProduct(int productId) throws ProductNotFound {
		Product matchProduct = getProduct(productId);
		products.remove(productId);
		return "Product Removed Successfully";
	}

	@Override
	public Product getProduct(int productId) throws ProductNotFound {
		Product product = products.get(productId);
		if (product != null)
			return product;
		else
			throw new ProductNotFound("There Is No Product With the given id:");
	}

	@Override
	public List<Product> getAllProducts() {
		Set<Integer> keys = products.keySet();
		List<Product> productInfo = new ArrayList<Product>();
		for (int key : keys) {
			Product product = products.get(key);
			productInfo.add(product);
		}
		return productInfo;
	}

	@Override
	public List<Product> getProductsBetween(float intialPrice, float finalPrice) {// 1000,2000
		Set<Integer> keys = products.keySet();
		List<Product> productInfo = new ArrayList<Product>();
		for (int key : keys) {
			Product product = products.get(key);
			float actualPrice = product.getProductPrice();// 1200
			if (actualPrice >= intialPrice && actualPrice <= finalPrice) {
				productInfo.add(product);
			}
		}
		return productInfo;
	}

	@Override
	public List<Product> getProductsByCategory(String productCategory) {
		Set<Integer> keys = products.keySet();
		List<Product> productInfo = new ArrayList<Product>();
		for (int key : keys) {
			Product product = products.get(key);
			String actualCategory = product.getProductCategory();// 1200
			if (actualCategory.equalsIgnoreCase(productCategory)) {
				productInfo.add(product);
			}
		}
		return productInfo;
	}

}
