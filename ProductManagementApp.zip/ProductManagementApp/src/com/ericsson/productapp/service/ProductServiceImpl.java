package com.ericsson.productapp.service;

import java.util.List;

import com.ericsson.productapp.dao.ProductDAO;
import com.ericsson.productapp.dao.ProductDAOImpl;
import com.ericsson.productapp.exceptions.ProductNotFound;
import com.ericsson.productapp.models.Product;

public class ProductServiceImpl implements ProductService {
	ProductDAO dao;

	public ProductServiceImpl() {
		dao = new ProductDAOImpl();
	}

	@Override
	public String addProduct(Product product) {

		return dao.addProduct(product);
	}

	@Override
	public Product updateProduct(Product product) throws ProductNotFound {

		return dao.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) throws ProductNotFound {

		return dao.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) throws ProductNotFound {

		return dao.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return dao.getAllProducts();
	}

	@Override
	public List<Product> getProductsBetween(float intialPrice, float finalPrice) {

		return dao.getProductsBetween(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getProductsByCategory(String productCategory) {

		return dao.getProductsByCategory(productCategory);
	}

}
