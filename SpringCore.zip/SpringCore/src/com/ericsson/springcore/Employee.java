package com.ericsson.springcore;

public class Employee {
	private int empno;
	private String empName;
	private int empSal;
	private String designation;

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSal() {
		return empSal;
	}

	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int empno, String empName, int empSal, String designation) {
		super();
		this.empno = empno;
		this.empName = empName;
		this.empSal = empSal;
		this.designation = designation;
	}

}
