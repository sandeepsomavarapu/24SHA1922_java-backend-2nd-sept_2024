package com.ericsson;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.ericsson")
public class Test {

	public static void main(String[] args) {

		ApplicationContext factory = new AnnotationConfigApplicationContext(Test.class);

		Employee emp = (Employee) factory.getBean("emp");// Object,Employee,Student
		System.out.println(emp);
		System.out.println(emp.getAddress());
		Employee emp1 = (Employee) factory.getBean("emp");
		System.out.println(emp1);
		System.out.println(emp1.getEmpno());

		// scope="singleton"

	}

}
