package com.ericsson.springcore;

public class Employee {
	private int empno;
	private String empName;
	private int empSal;
	private String designation;
	private Address address;// has-a

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSal() {
		return empSal;
	}

	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Employee() {
		System.out.println("Default Constructor-Employee");
	}

	public Employee(int empno, String empName, int empSal, String designation, Address address) {
		super();
		this.empno = empno;
		this.empName = empName;
		this.empSal = empSal;
		this.designation = designation;
		this.address = address;
	}

	public Employee(Address address) {
		super();
		System.out.println("Param Constructor-Address Injection");
		this.address = address;
	}

}
