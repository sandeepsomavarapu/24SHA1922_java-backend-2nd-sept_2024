package com.ericsson.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {

//		Resource resource = new ClassPathResource("springconfig.xml");
//		BeanFactory factory = new XmlBeanFactory(resource);
		
		ApplicationContext factory=new ClassPathXmlApplicationContext("springconfig.xml");
		
//		Employee emp = (Employee) factory.getBean("emp");// Object,Employee,Student
//		System.out.println(emp);
//		
		
		
		
//		System.out.println(emp.getAddress());
//		Employee emp1 = (Employee) factory.getBean("emp");
//		System.out.println(emp1);
//		Employee emp2= (Employee) factory.getBean("emp");
//		System.out.println(emp2);
		
		
		//scope="singleton"
	
	}

}
